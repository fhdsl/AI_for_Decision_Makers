




# Ethical process

The concepts for ethical AI use are still highly debated as this is a rapidly evolving field. 

However, here is a proposed framework for using AI more ethically.

