



# Consent and AI

ChatGPT example for Samsung or use that earlier?
